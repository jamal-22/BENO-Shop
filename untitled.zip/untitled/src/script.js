// تهيئة السلايدر
const swiper = new Swiper('.mySwiper', {
    loop: true,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    autoplay: {
        delay: 5000,
    },
});

// إضافة تأثيرات التمرير
window.addEventListener('scroll', () => {
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        const cardTop = card.getBoundingClientRect().top;
        if (cardTop < window.innerHeight * 0.8) {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }
    });
});

// تفعيل معاينة سريعة
document.querySelectorAll('.quick-view').forEach(btn => {
    btn.addEventListener('click', () => {
        alert('المعاينة السريعة قريبًا! ⏳');
    });
});

// إضافة منتج للسلة
document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.classList.add('added');
        setTimeout(() => btn.classList.remove('added'), 1000);
    });
});